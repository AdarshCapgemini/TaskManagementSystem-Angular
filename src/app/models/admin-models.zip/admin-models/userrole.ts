export class Userrole {
    userRoleId!:number;
    roleName!:string
}
