export class User {
    userId!:number
    userName!:string
    password!:string
    email!:string
    fullName!:string
    roleName!:string[]
}
