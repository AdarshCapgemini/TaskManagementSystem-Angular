export class Attachment {
    attachmentId!:number
    fileName!:string;
    filePath!:string;
}
