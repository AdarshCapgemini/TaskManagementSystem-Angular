export class Task {
    taskId!: number;
    taskName!: string;
    description!: string;
    dueDate!: Date;
    priority!: string;
    status!: string;
    projectId!: number;
    userId!: number
}
