import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../../service/admin.service';
import { User } from '../../../models/user';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from "../../layout/header/header.component";
import { SidebarComponent } from "../../layout/sidebar/sidebar.component";
import { UserComponent } from "../../user/user.component";
import { ProjectComponent } from "../../project/project.component";
import { TaskComponent } from "../../task/task.component";
import { AdminNavbarComponent } from '../admin-navbar/admin-navbar.component';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, AdminNavbarComponent, SidebarComponent, UserComponent, ProjectComponent, TaskComponent],
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.css'
})
export class AdminDashboardComponent implements OnInit{
  user!: User

  constructor() { }

  ngOnInit(): void {

  }
}
