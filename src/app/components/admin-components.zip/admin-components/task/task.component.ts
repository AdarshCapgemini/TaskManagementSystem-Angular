import { Component, OnInit } from '@angular/core';
import { Task } from '../../models/task';
import { TaskService } from '../../service/task.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-task',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './task.component.html',
  styleUrl: './task.component.css'
})
export class TaskComponent implements OnInit{
  tasks!:Task[]

  constructor(private taskService:TaskService){}
  ngOnInit(): void {
    this.getTaskByUserId(2)
  }

  getTaskByUserId(userId:number):void{
    this.taskService.getTaskByUserId(userId).subscribe(
      data => {this.tasks = data;}
    )
  }
}
