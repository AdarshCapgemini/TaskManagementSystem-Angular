import { Component } from '@angular/core';

@Component({
  selector: 'app-view-tasks',
  standalone: true,
  imports: [],
  templateUrl: './view-tasks.component.html',
  styleUrl: './view-tasks.component.css'
})
export class ViewTasksComponent {

}
