import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { Attachment } from '../../../models/attachment';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-single-attachment',
  standalone: true,
  imports: [CommonModule,RouterModule],
  templateUrl: './single-attachment.component.html',
  styleUrl: './single-attachment.component.css'
})
export class SingleAttachmentComponent {
  @Input({required:true}) attachment!:Attachment

}
