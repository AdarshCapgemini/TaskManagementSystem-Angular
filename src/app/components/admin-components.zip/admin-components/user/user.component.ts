import { Component, OnInit } from '@angular/core';
import { User } from '../../models/user';
import { UserService } from '../../service/user.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './user.component.html',
  styleUrl: './user.component.css'
})
export class UserComponent implements OnInit{
  user!:User

  constructor(private userService:UserService){}

ngOnInit(): void {
  this.getUserById(2)
}

getUserById(userId: number): void {
  this.userService.getUserById(userId).subscribe(
    (data) => { this.user = data; },
    (error) => { console.log(error); }
  );
}


}
