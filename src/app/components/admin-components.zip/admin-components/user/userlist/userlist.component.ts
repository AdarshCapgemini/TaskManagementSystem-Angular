import { AfterViewInit, Component, OnInit } from '@angular/core';
import { User } from '../../../models/user';
import { AdminService } from '../../../service/admin.service';
import { UserService } from '../../../service/user.service';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { AdminNavbarComponent } from '../../admin/admin-navbar/admin-navbar.component';
import { RouterModule } from '@angular/router';

declare var bootstrap: any;

@Component({
  selector: 'app-userlist',
  standalone: true,
  imports: [CommonModule, AdminNavbarComponent, RouterModule],
  templateUrl: './userlist.component.html',
  styleUrl: './userlist.component.css'
})
export class UserlistComponent implements OnInit,AfterViewInit{
  users!: User[];

  constructor(private adminService: AdminService, private userService: UserService) {}

  ngOnInit(): void {
    this.userService.getAllUsers().subscribe(
      data => {
        this.users = data;
        console.log(this.users);
      },
      error => {
        console.error('Failed to fetch users', error);
      }
    );
  }

  ngAfterViewInit(): void {
    // Ensure that Bootstrap is loaded and used only in the browser
    if (typeof bootstrap !== 'undefined') {
      const dropdownElements = document.querySelectorAll('.dropdown-toggle');
      dropdownElements.forEach((element) => {
        try {
          new bootstrap.Dropdown(element);
        } catch (e) {
          console.error('Failed to create dropdown', e);
        }
      });
    }
  }

  deleteUser(userId: number): void {
    this.adminService.deleteUser(userId).subscribe(
      data => {
        this.users = data;
      },
      error => {
        console.error('Failed to delete user', error);
      }
    );
  }

  updateUser(userId: number, updatedUser: any): void {
    this.adminService.updateUser(userId, updatedUser).subscribe(
      data => {
        this.users = data;
      },
      error => {
        console.error('Failed to update user', error);
      }
    );
  }
}
