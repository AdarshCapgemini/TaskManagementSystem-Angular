import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { Task } from '../../../models/task';
import { ProjectService } from '../../../service/project.service';
import { ActivatedRoute, Router } from '@angular/router';
import { TaskService } from '../../../service/task.service';

@Component({
  selector: 'app-view-tasks-by-project-id',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './view-tasks-by-project-id.component.html',
  styleUrl: './view-tasks-by-project-id.component.css'
})
export class ViewTasksByProjectIdComponent implements OnInit{
  tasks!:Task[];
  projectId!:number
  
  constructor(private projectService: ProjectService, private router: Router, private taskService: TaskService, private route:ActivatedRoute) { }
  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.getAllTasksForProjectId(params['projectId']);
    })
  }

  getAllTasksForProjectId(projectId:number)
  {
    this.taskService.getTaskByProjectId(projectId).subscribe(
      data => {
        this.tasks = data;
      },
    )
  }

}
